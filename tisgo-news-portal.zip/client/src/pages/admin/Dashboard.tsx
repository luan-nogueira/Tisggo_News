import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, Edit2, Trash2, Plus, Eye, FileText, Users, TrendingUp } from "lucide-react";
import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Link, useLocation } from "wouter";

export default function Dashboard() {
  const { user, logout } = useAuth();
  const [, navigate] = useLocation();
  const { data: articles, isLoading: articlesLoading } = trpc.articles.list.useQuery();
  const { data: categories } = trpc.categories.list.useQuery();
  const deleteArticle = trpc.articles.delete.useMutation();

  if (!user || user.role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-black">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-white mb-4">Acesso Negado</h1>
          <p className="text-gray-400 mb-6">Você não tem permissão para acessar o painel administrativo.</p>
          <Link href="/" className="text-accent hover:underline">
            Voltar para home
          </Link>
        </div>
      </div>
    );
  }

  const totalArticles = articles?.length || 0;
  const totalViews = articles?.reduce((sum, a) => sum + (a.views || 0), 0) || 0;
  const publishedArticles = articles?.filter(a => a.published).length || 0;

  const handleDelete = async (id: number) => {
    if (confirm("Tem certeza que deseja deletar este artigo?")) {
      try {
        await deleteArticle.mutateAsync(id);
        window.location.reload();
      } catch (error) {
        console.error("Erro ao deletar:", error);
      }
    }
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <header className="bg-black border-b border-gray-800 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link href="/" className="text-2xl font-black">
                <span className="text-accent">TISGO</span>
                <span className="text-white">NEWS</span>
              </Link>
              <span className="text-gray-500 text-sm font-bold">PAINEL ADMIN</span>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-sm text-gray-400">{user.email}</span>
              <Button
                onClick={() => logout()}
                className="bg-accent text-black hover:bg-yellow-500 font-bold text-sm"
              >
                Sair
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Back Button */}
        <Link href="/" className="inline-flex items-center gap-2 text-gray-400 hover:text-accent transition-colors mb-8">
          <span>← Voltar para o Site</span>
        </Link>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
          <div className="bg-gray-900 border border-gray-800 rounded p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm uppercase font-bold">Notícias</p>
                <p className="text-4xl font-black text-white mt-2">{totalArticles}</p>
              </div>
              <FileText className="w-12 h-12 text-accent opacity-50" />
            </div>
          </div>

          <div className="bg-gray-900 border border-gray-800 rounded p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm uppercase font-bold">Visualizações</p>
                <p className="text-4xl font-black text-white mt-2">{totalViews.toLocaleString('pt-BR')}</p>
              </div>
              <Eye className="w-12 h-12 text-accent opacity-50" />
            </div>
          </div>

          <div className="bg-gray-900 border border-gray-800 rounded p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm uppercase font-bold">Publicadas</p>
                <p className="text-4xl font-black text-white mt-2">{publishedArticles}</p>
              </div>
              <TrendingUp className="w-12 h-12 text-accent opacity-50" />
            </div>
          </div>

          <div className="bg-gray-900 border border-gray-800 rounded p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm uppercase font-bold">Categorias</p>
                <p className="text-4xl font-black text-white mt-2">{categories?.length || 0}</p>
              </div>
              <Users className="w-12 h-12 text-accent opacity-50" />
            </div>
          </div>
        </div>

        {/* Articles Management */}
        <div className="bg-gray-900 border border-gray-800 rounded">
          <div className="flex items-center justify-between p-6 border-b border-gray-800">
            <h2 className="text-2xl font-black uppercase">Gerenciar Notícias</h2>
            <Link href="/admin/articles/new">
              <Button className="bg-accent text-black hover:bg-yellow-500 font-bold flex items-center gap-2">
                <Plus className="w-4 h-4" />
                Nova Notícia
              </Button>
            </Link>
          </div>

          {articlesLoading ? (
            <div className="flex items-center justify-center p-12">
              <Loader2 className="w-8 h-8 animate-spin text-accent" />
            </div>
          ) : articles && articles.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="border-b border-gray-800 bg-gray-800/50">
                  <tr>
                    <th className="text-left px-6 py-4 font-bold uppercase text-xs text-gray-400">Título</th>
                    <th className="text-left px-6 py-4 font-bold uppercase text-xs text-gray-400">Categoria</th>
                    <th className="text-left px-6 py-4 font-bold uppercase text-xs text-gray-400">Views</th>
                    <th className="text-left px-6 py-4 font-bold uppercase text-xs text-gray-400">Data</th>
                    <th className="text-left px-6 py-4 font-bold uppercase text-xs text-gray-400">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {articles.map((article) => (
                    <tr key={article.id} className="border-b border-gray-800 hover:bg-gray-800/50 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          {article.published && (
                            <Badge className="bg-green-600 text-white hover:bg-green-700 text-xs font-bold">
                              PUBLICADO
                            </Badge>
                          )}
                          <span className="font-bold text-white line-clamp-1">{article.title}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-gray-400 text-sm">
                        {categories?.find(c => c.id === article.categoryId)?.name}
                      </td>
                      <td className="px-6 py-4 text-gray-400 text-sm">{article.views || 0}</td>
                      <td className="px-6 py-4 text-gray-400 text-sm">
                        {new Date(article.publishedAt || article.createdAt).toLocaleDateString('pt-BR')}
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <Link href={`/admin/articles/${article.id}/edit`}>
                            <Button
                              size="sm"
                              variant="outline"
                              className="border-gray-700 hover:border-accent text-gray-400 hover:text-accent"
                            >
                              <Edit2 className="w-4 h-4" />
                            </Button>
                          </Link>
                          <Button
                            size="sm"
                            variant="outline"
                            className="border-gray-700 hover:border-red-600 text-gray-400 hover:text-red-600"
                            onClick={() => handleDelete(article.id)}
                            disabled={deleteArticle.isPending}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-center py-12 text-gray-400">
              <p>Nenhuma notícia encontrada. Crie a primeira!</p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
